# [E-Commerce Website](https://abhijit49.github.io/E-Commerce-Website-CARA-/)

This is a E-Commerce Website. This project is based on HTML, CSS, JS.

![image](https://user-images.githubusercontent.com/34413515/199085619-dc393b0c-588d-42f9-8e16-cf10acbdc1c6.png)

## Rules
- DO NOT COMMIT DIRECTLY TO main branch

## Tech Stack
-  HTML, CSS, JS.

## To Contribute

- Open a [new issue](https://github.com/abhijit49/E-Commerce-Website-CARA-/issues/new)
- Fork this repo
- Create a new branch 
- Write code and push your code in your forked repo branch.
- Create a PR

## Website link
- https://abhijit49.github.io/E-Commerce-Website-CARA-/

## Support
1. Report bug/issue
2. Suggest new feature
3. Star this repository


<hr/>
This repo is maintained by <a href="https://github.com/abhijit49/">me.</a>





